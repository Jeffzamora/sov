<?php
// Compat: ruta /login/cerrar_sesion.php
require_once __DIR__ . '/../app/controllers/login/cerrar_sesion.php';
