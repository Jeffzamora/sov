<?php
// Backward compatible endpoint (index.php usa movimiento.php)
require_once __DIR__ . '/movimientos.php';
